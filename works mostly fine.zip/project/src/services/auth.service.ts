import { supabase } from '../lib/supabase';
import { User } from '../types';

export const authService = {
  async signIn(email: string, password: string, role: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;

    const { data: userData } = await supabase
      .from('users')
      .select('*')
      .eq('id', data.user.id)
      .single();

    return userData;
  },

  async signUp(email: string, password: string, name: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });
    if (error) throw error;

    if (data.user) {
      await supabase.from('users').insert([
        {
          id: data.user.id,
          email,
          name,
          role: 'customer',
        },
      ]);
    }

    return data;
  },

  async signOut() {
    return await supabase.auth.signOut();
  },

  async updateProfile(data: Partial<User>) {
    const { error } = await supabase
      .from('users')
      .update(data)
      .eq('id', data.id);
    if (error) throw error;
    return true;
  },
};