import React from 'react';
import { useTheme } from '../../hooks/useTheme';
import ChatInterface from '../../components/ChatInterface';

const Chat = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <h1 className="text-3xl font-bold mb-8">Chat with PC Building Specialist</h1>
      <ChatInterface />
    </div>
  );
};

export default Chat;