import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { useTheme } from '../../hooks/useTheme';

const Home = () => {
  const { user } = useAuthStore();
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4">Welcome to PC Builder</h1>
        <p className="text-xl mb-8">Your one-stop shop for all PC components</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800">
            <h2 className="text-2xl font-semibold mb-4">Brand New Shop</h2>
            <p className="mb-4">Explore our collection of brand new PC components from top manufacturers.</p>
            <a href="/brand-new-shop" className="inline-block bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600">
              Shop New
            </a>
          </div>
          
          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800">
            <h2 className="text-2xl font-semibold mb-4">Used Shop</h2>
            <p className="mb-4">Find great deals on quality used PC components.</p>
            <a href="/used-shop" className="inline-block bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600">
              Shop Used
            </a>
          </div>
        </div>
      </section>

      {!user && (
        <section className="text-center py-12 bg-gray-100 dark:bg-gray-800 mt-12">
          <h2 className="text-2xl font-bold mb-4">Get Started Today</h2>
          <p className="mb-6">Create an account to start building your perfect PC</p>
          <a href="/register" className="inline-block bg-purple-500 text-white px-6 py-2 rounded-lg hover:bg-purple-600">
            Sign Up Now
          </a>
        </section>
      )}
    </div>
  );
};

export default Home;