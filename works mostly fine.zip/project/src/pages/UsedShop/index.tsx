import React from 'react';
import ProductList from '../../components/ProductList';
import { useTheme } from '../../hooks/useTheme';

const UsedShop = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <h1 className="text-3xl font-bold mb-8">Used Components</h1>
      <ProductList shopType="used" />
    </div>
  );
};

export default UsedShop;