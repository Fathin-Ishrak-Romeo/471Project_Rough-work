import React from 'react';
import { useTheme } from '../../hooks/useTheme';
import CartList from '../../components/CartList';

const Cart = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      <CartList />
    </div>
  );
};

export default Cart;