import React, { useState } from 'react';
import ProductForm from './ProductForm';
import ProductTable from './ProductTable';
import { Product } from '../../types';
import { useTheme } from '../../hooks/useTheme';

const ProductManagement = () => {
  const { isDarkMode } = useTheme();
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  return (
    <div className={`space-y-8 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <ProductForm editingProduct={editingProduct} onCancel={() => setEditingProduct(null)} />
      <ProductTable onEditProduct={setEditingProduct} />
    </div>
  );
};

export default ProductManagement;