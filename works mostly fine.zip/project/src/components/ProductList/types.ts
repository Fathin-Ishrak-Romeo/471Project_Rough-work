export interface FilterState {
  category: string | null;
  brand: string | null;
  minPrice: number | null;
  maxPrice: number | null;
  condition: 'new' | 'used' | null;
}