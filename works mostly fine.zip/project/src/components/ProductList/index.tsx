import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Product } from '../../types';
import ProductCard from './ProductCard';
import ProductFilters from './ProductFilters';
import { useFilters } from './useFilters';
import { FilterState } from './types';

interface ProductListProps {
  shopType: 'brand_new' | 'used';
}

const ProductList = ({ shopType }: ProductListProps) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { filters, updateFilter, resetFilters } = useFilters();

  useEffect(() => {
    loadProducts(filters);
  }, [filters, shopType]);

  const loadProducts = async (filterState: FilterState) => {
    try {
      setLoading(true);
      let query = supabase
        .from('products')
        .select('*')
        .eq('shop_type', shopType);

      // Apply filters
      if (filterState.category) {
        query = query.eq('category', filterState.category);
      }
      if (filterState.brand) {
        query = query.eq('brand', filterState.brand);
      }
      if (filterState.minPrice) {
        query = query.gte('price', filterState.minPrice);
      }
      if (filterState.maxPrice) {
        query = query.lte('price', filterState.maxPrice);
      }
      if (filterState.condition) {
        query = query.eq('condition', filterState.condition);
      }

      const { data, error } = await query;
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <ProductFilters
        filters={filters}
        onUpdateFilter={updateFilter}
        onReset={resetFilters}
      />
      
      {loading ? (
        <div className="text-center py-8">Loading products...</div>
      ) : products.length === 0 ? (
        <div className="text-center py-8">No products found</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductList;