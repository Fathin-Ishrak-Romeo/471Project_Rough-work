import React from 'react';
import { FilterState } from './types';

interface ProductFiltersProps {
  filters: FilterState;
  onUpdateFilter: (key: keyof FilterState, value: string | number | null) => void;
  onReset: () => void;
}

const ProductFilters = ({ filters, onUpdateFilter, onReset }: ProductFiltersProps) => {
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Category</label>
          <select
            value={filters.category || ''}
            onChange={(e) => onUpdateFilter('category', e.target.value || null)}
            className="w-full p-2 border rounded-md dark:bg-gray-700"
          >
            <option value="">All Categories</option>
            <option value="processor">Processor</option>
            <option value="graphics_card">Graphics Card</option>
            <option value="motherboard">Motherboard</option>
            <option value="ram">RAM</option>
            <option value="storage">Storage</option>
            <option value="power_supply">Power Supply</option>
            <option value="case">Case</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Brand</label>
          <input
            type="text"
            value={filters.brand || ''}
            onChange={(e) => onUpdateFilter('brand', e.target.value || null)}
            placeholder="Enter brand name"
            className="w-full p-2 border rounded-md dark:bg-gray-700"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Price Range</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={filters.minPrice || ''}
              onChange={(e) => onUpdateFilter('minPrice', e.target.value ? Number(e.target.value) : null)}
              placeholder="Min"
              className="w-full p-2 border rounded-md dark:bg-gray-700"
            />
            <input
              type="number"
              value={filters.maxPrice || ''}
              onChange={(e) => onUpdateFilter('maxPrice', e.target.value ? Number(e.target.value) : null)}
              placeholder="Max"
              className="w-full p-2 border rounded-md dark:bg-gray-700"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Condition</label>
          <select
            value={filters.condition || ''}
            onChange={(e) => onUpdateFilter('condition', e.target.value || null)}
            className="w-full p-2 border rounded-md dark:bg-gray-700"
          >
            <option value="">All Conditions</option>
            <option value="new">New</option>
            <option value="used">Used</option>
          </select>
        </div>
      </div>

      <div className="mt-4 flex justify-end">
        <button
          onClick={onReset}
          className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white"
        >
          Reset Filters
        </button>
      </div>
    </div>
  );
};

export default ProductFilters;