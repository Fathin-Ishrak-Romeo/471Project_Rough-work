import React, { Suspense } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Float } from '@react-three/drei';
import { Computer } from '../3D/Computer';
import { ThemeToggle } from '../Layout/ThemeToggle';

export const Hero = () => {
  return (
    <div className="relative h-screen">
      <div className="absolute inset-0">
        <Canvas>
          <Suspense fallback={null}>
            <OrbitControls enableZoom={false} />
            <ambientLight intensity={0.5} />
            <directionalLight position={[10, 10, 5]} intensity={1} />
            <Float speed={1.4} rotationIntensity={1.5} floatIntensity={2}>
              <Computer />
            </Float>
          </Suspense>
        </Canvas>
      </div>
      <div className="absolute top-4 right-4 z-20">
        <ThemeToggle />
      </div>
      <div className="relative z-10 flex items-center justify-center h-full bg-gradient-to-b from-transparent to-gray-900/50">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center text-white"
        >
          <h1 className="text-6xl font-bold mb-6">Build Your Dream PC</h1>
          <p className="text-xl mb-8">Custom builds by expert specialists</p>
          <div className="space-x-4">
            <Link to="/signup">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700"
              >
                Sign Up Now
              </motion.button>
            </Link>
            <Link to="/login">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100"
              >
                Login
              </motion.button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
};