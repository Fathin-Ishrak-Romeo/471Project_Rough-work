import React from 'react';
import { motion } from 'framer-motion';

export const About = () => {
  return (
    <div className="py-16 bg-gray-50 dark:bg-gray-800 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">About PC Builder</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">Building dreams, one PC at a time</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md"
          >
            <h3 className="text-2xl font-semibold mb-4 dark:text-white">Our Mission</h3>
            <p className="text-gray-600 dark:text-gray-300">
              To provide high-quality custom PC builds and expert guidance for every budget and need.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md"
          >
            <h3 className="text-2xl font-semibold mb-4 dark:text-white">Expert Team</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Our specialists have years of experience in PC building and component selection.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow-md"
          >
            <h3 className="text-2xl font-semibold mb-4 dark:text-white">Quality First</h3>
            <p className="text-gray-600 dark:text-gray-300">
              We use only genuine components and provide warranty support for peace of mind.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
};