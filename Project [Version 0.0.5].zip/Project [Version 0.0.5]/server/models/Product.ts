import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
  },
  price: {
    bdt: {
      type: Number,
      required: [true, 'BDT price is required'],
    },
    usd: {
      type: Number,
      required: [true, 'USD price is required'],
    },
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: ['processor', 'graphics-card', 'motherboard', 'ram', 'storage', 'power-supply', 'case', 'laptop'],
  },
  brand: {
    type: String,
    required: [true, 'Brand is required'],
  },
  condition: {
    type: String,
    required: [true, 'Condition is required'],
    enum: ['new', 'used'],
  },
  images: [String],
  specs: {
    type: Map,
    of: String,
  },
  stock: {
    type: Number,
    required: [true, 'Stock quantity is required'],
    min: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export const Product = mongoose.model('Product', productSchema);