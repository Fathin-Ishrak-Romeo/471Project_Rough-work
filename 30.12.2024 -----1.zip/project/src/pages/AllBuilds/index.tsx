import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { supabase } from '../../lib/supabase';
import { SavedBuild } from '../../types';
import { useAuthStore } from '../../store/authStore';

const AllBuilds = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [builds, setBuilds] = useState<SavedBuild[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/signin');
      return;
    }
    fetchBuilds();
  }, [user, navigate]);

  const fetchBuilds = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_builds')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBuilds(data || []);
    } catch (error) {
      console.error('Error fetching builds:', error);
      toast.error('Failed to load saved builds');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async (build: SavedBuild) => {
    try {
      const components = Object.values(build.components);
      const cartItems = components.map(component => ({
        product_id: component.id,
        user_id: user?.id,
        quantity: 1
      }));

      const { error } = await supabase
        .from('cart_items')
        .insert(cartItems);

      if (error) throw error;
      toast.success('Build added to cart');
    } catch (error) {
      console.error('Error adding to cart:', error);
      toast.error('Failed to add build to cart');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 dark:text-white">Saved Builds</h1>

      {builds.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">No saved builds found</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {builds.map((build) => (
            <div key={build.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4 dark:text-white">{build.name}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-2">
                Category: {build.usage_category}
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Total: ৳{build.total_price}
              </p>

              <div className="space-y-4 mb-6">
                {Object.entries(build.components).map(([category, component]) => (
                  <div key={category} className="flex items-center gap-4">
                    <img
                      src={component.image_url}
                      alt={component.name}
                      className="w-12 h-12 object-cover rounded"
                    />
                    <div>
                      <p className="font-medium dark:text-white">{component.name}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{category}</p>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => handleAddToCart(build)}
                className="w-full bg-primary-500 text-white py-2 rounded-lg hover:bg-primary-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AllBuilds;