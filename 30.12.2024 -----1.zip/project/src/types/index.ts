// Add to existing types
export interface SavedBuild {
  id: string;
  user_id: string;
  name: string;
  components: Record<string, Product>;
  usage_category: string;
  total_price: number;
  created_at: string;
}