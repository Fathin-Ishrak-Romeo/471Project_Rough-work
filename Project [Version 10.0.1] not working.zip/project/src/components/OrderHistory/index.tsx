import React, { useEffect, useState } from 'react';
import { orderService } from '../../services/order.service';
import { useAuthStore } from '../../store/authStore';
import OrderHistoryItem from './OrderHistoryItem';
import type { Order } from '../../types';

const OrderHistory: React.FC = () => {
  const { user } = useAuthStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadOrders();
    }
  }, [user]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const data = await orderService.getOrderHistory(user!.id);
      setOrders(data);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="text-center p-8 dark:text-gray-200">
        Please login to view your order history
      </div>
    );
  }

  if (loading) {
    return (
      <div className="text-center p-8 dark:text-gray-200">
        Loading order history...
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center p-8 dark:text-gray-200">
        No orders found
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {orders.map((order) => (
        <OrderHistoryItem key={order.id} order={order} />
      ))}
    </div>
  );
};

export default OrderHistory;