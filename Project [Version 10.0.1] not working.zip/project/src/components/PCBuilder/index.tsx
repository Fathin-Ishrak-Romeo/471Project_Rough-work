import React, { useState } from 'react';
import { aiService } from '../../services/ai.service';
import PCBuilderForm from './PCBuilderForm';
import PCBuildResult from './PCBuildResult';
import type { PCBuildRequest } from './types';

const PCBuilder = () => {
  const [buildResult, setBuildResult] = useState<PCBuildResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleBuildRequest = async (request: PCBuildRequest) => {
    setLoading(true);
    setError(null);
    try {
      const result = await aiService.generatePCBuild(request);
      setBuildResult(result);
    } catch (err) {
      setError('Failed to generate PC build. Please try again.');
      console.error('Error generating PC build:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Build Your Dream PC</h2>
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        {!buildResult ? (
          <PCBuilderForm onSubmit={handleBuildRequest} loading={loading} />
        ) : (
          <PCBuildResult result={buildResult} onReset={() => setBuildResult(null)} />
        )}
      </div>
    </div>
  );
};

export default PCBuilder;