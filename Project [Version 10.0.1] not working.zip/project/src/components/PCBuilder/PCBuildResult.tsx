import React from 'react';
import { useNavigate } from 'react-router-dom';
import type { PCBuildResult } from './types';
import { formatCurrency } from '../../utils/currency';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';

interface PCBuildResultProps {
  result: PCBuildResult;
  onReset: () => void;
}

const PCBuildResult: React.FC<PCBuildResultProps> = ({ result, onReset }) => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const totalCost = result.components.reduce((sum, comp) => sum + comp.price, 0);

  const handleAddToCart = async () => {
    if (!user) {
      alert('Please login to add items to cart');
      navigate('/login');
      return;
    }

    try {
      const cartItems = result.components.map(component => ({
        user_id: user.id,
        product_id: component.id,
        quantity: 1,
      }));

      const { error } = await supabase
        .from('cart_items')
        .insert(cartItems);

      if (error) throw error;
      
      alert('All components added to cart successfully!');
      navigate('/cart');
    } catch (error) {
      console.error('Error adding components to cart:', error);
      alert('Failed to add components to cart. Please try again.');
    }
  };

  return (
    <div className="space-y-6 dark:text-white">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Recommended Build</h3>
        <button
          onClick={onReset}
          className="text-blue-500 hover:text-blue-600 dark:text-blue-400"
        >
          Start New Build
        </button>
      </div>

      <div className="space-y-4">
        {result.components.map((component) => (
          <div
            key={component.id}
            className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg transform hover:scale-[1.02] transition-all"
          >
            <div>
              <h4 className="font-medium">{component.name}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {component.description}
              </p>
            </div>
            <span className="font-medium">{formatCurrency(component.price)}</span>
          </div>
        ))}
      </div>

      <div className="border-t dark:border-gray-700 pt-4">
        <div className="flex justify-between items-center">
          <span className="text-lg font-semibold">Total Cost:</span>
          <span className="text-lg font-semibold">{formatCurrency(totalCost)}</span>
        </div>
      </div>

      <button
        onClick={handleAddToCart}
        className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transform hover:translate-y-[-2px] transition-all"
      >
        Add All to Cart
      </button>
    </div>
  );
};