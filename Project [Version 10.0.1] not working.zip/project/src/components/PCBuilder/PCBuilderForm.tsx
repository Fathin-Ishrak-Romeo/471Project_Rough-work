import React, { useState } from 'react';
import { categories } from './categories';
import type { PCBuildRequest } from './types';

interface PCBuilderFormProps {
  onSubmit: (request: PCBuildRequest) => void;
  loading: boolean;
}

const PCBuilderForm: React.FC<PCBuilderFormProps> = ({ onSubmit, loading }) => {
  const [formData, setFormData] = useState({
    category: '',
    minBudget: '',
    maxBudget: '',
    preferences: [] as string[],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      category: formData.category,
      budget: {
        min: parseInt(formData.minBudget),
        max: parseInt(formData.maxBudget),
      },
      preferences: formData.preferences,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">Usage Category</label>
        <select
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          className="w-full p-2 border rounded-lg"
          required
        >
          <option value="">Select category</option>
          {categories.map((cat) => (
            <option key={cat.value} value={cat.value}>
              {cat.label}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">Min Budget ($)</label>
          <input
            type="number"
            value={formData.minBudget}
            onChange={(e) => setFormData({ ...formData, minBudget: e.target.value })}
            className="w-full p-2 border rounded-lg"
            required
            min="0"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Max Budget ($)</label>
          <input
            type="number"
            value={formData.maxBudget}
            onChange={(e) => setFormData({ ...formData, maxBudget: e.target.value })}
            className="w-full p-2 border rounded-lg"
            required
            min="0"
          />
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50"
        disabled={loading}
      >
        {loading ? 'Generating Build...' : 'Generate PC Build'}
      </button>
    </form>
  );
};

export default PCBuilderForm;