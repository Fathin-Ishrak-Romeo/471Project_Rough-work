import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle } from 'lucide-react';
import { chatQuestions, ChatQuestion } from '../../data/chatbot-qa';
import ChatHeader from './ChatHeader';
import ChatWindow from './ChatWindow';
import { Message } from './types';
import { handleChatResponse } from './utils';

interface ChatBotProps {
  isVisible: boolean;
  onClose: () => void;
}

const ChatBot: React.FC<ChatBotProps> = ({ isVisible, onClose }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentQuestions, setCurrentQuestions] = useState(chatQuestions);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleQuestionSelect = (question: ChatQuestion) => {
    handleChatResponse(question, setMessages, setCurrentQuestions);
  };

  return (
    <div
      className={`fixed bottom-4 right-4 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-xl transition-all transform ${
        isVisible ? 'scale-100' : 'scale-0'
      } ${isMinimized ? 'h-12' : 'h-[500px]'} hover:shadow-2xl`}
    >
      <ChatHeader
        onMinimize={() => setIsMinimized(!isMinimized)}
        onClose={onClose}
      />

      {!isMinimized && (
        <ChatWindow
          messages={messages}
          currentQuestions={currentQuestions}
          onQuestionSelect={handleQuestionSelect}
          messagesEndRef={messagesEndRef}
        />
      )}
    </div>
  );
};

export default ChatBot;