import React from 'react';
import { Minus, X } from 'lucide-react';

interface ChatHeaderProps {
  onMinimize: () => void;
  onClose: () => void;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({ onMinimize, onClose }) => {
  return (
    <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
      <h3 className="font-semibold">PC Building Assistant</h3>
      <div className="flex items-center space-x-2">
        <button
          onClick={onMinimize}
          className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          <Minus size={18} />
        </button>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          <X size={18} />
        </button>
      </div>
    </div>
  );
};

export default ChatHeader;