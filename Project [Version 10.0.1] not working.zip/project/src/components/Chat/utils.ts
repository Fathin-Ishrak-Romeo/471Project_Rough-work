import { ChatQuestion } from '../../data/chatbot-qa';
import { Message } from './types';
import { chatQuestions } from '../../data/chatbot-qa';

export const handleChatResponse = (
  question: ChatQuestion,
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>,
  setCurrentQuestions: React.Dispatch<React.SetStateAction<ChatQuestion[]>>
) => {
  // Add user question
  setMessages(prev => [...prev, {
    id: Date.now().toString(),
    content: question.question,
    sender: 'user',
    timestamp: new Date()
  }]);

  // Add bot response
  setTimeout(() => {
    setMessages(prev => [...prev, {
      id: (Date.now() + 1).toString(),
      content: question.answer,
      sender: 'bot',
      timestamp: new Date()
    }]);

    // Update available questions to follow-ups if any
    if (question.followUpQuestions) {
      const followUps = chatQuestions.filter(q => 
        question.followUpQuestions?.includes(q.id)
      );
      setCurrentQuestions(followUps);
    } else {
      setCurrentQuestions(chatQuestions);
    }
  }, 500);
};