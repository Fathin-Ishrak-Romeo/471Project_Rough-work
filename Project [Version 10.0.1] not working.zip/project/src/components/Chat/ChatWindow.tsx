import React from 'react';
import { Message } from './types';
import { ChatQuestion, chatQuestions } from '../../data/chatbot-qa';
import ChatMessage from './ChatMessage';
import QuestionList from './QuestionList';

interface ChatWindowProps {
  messages: Message[];
  currentQuestions: ChatQuestion[];
  onQuestionSelect: (question: ChatQuestion) => void;
  messagesEndRef: React.RefObject<HTMLDivElement>;
}

const ChatWindow: React.FC<ChatWindowProps> = ({
  messages,
  currentQuestions,
  onQuestionSelect,
  messagesEndRef,
}) => {
  return (
    <div className="flex flex-col h-[calc(400px-48px)]">
      <div className="flex-1 overflow-y-auto p-4">
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t dark:border-gray-700 p-4 bg-gray-50 dark:bg-gray-900">
        <div className="flex justify-between items-center mb-2">
          <h4 className="text-sm font-medium dark:text-gray-200">Suggested Questions:</h4>
          <button
            onClick={() => onQuestionSelect(chatQuestions[0])}
            className="text-xs text-blue-500 hover:text-blue-600 dark:text-blue-400"
          >
            View All Questions
          </button>
        </div>
        <div className="max-h-24 overflow-y-auto">
          <QuestionList
            questions={currentQuestions}
            onSelectQuestion={onQuestionSelect}
          />
        </div>
      </div>
    </div>
  );
};