import React from 'react';
import { ChatQuestion } from '../../data/chatbot-qa';

interface QuestionListProps {
  questions: ChatQuestion[];
  onSelectQuestion: (question: ChatQuestion) => void;
}

const QuestionList: React.FC<QuestionListProps> = ({ questions, onSelectQuestion }) => {
  return (
    <div className="space-y-2">
      {questions.map((q) => (
        <button
          key={q.id}
          onClick={() => onSelectQuestion(q)}
          className="w-full text-left p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
        >
          {q.question}
        </button>
      ))}
    </div>
  );
};

export default QuestionList;