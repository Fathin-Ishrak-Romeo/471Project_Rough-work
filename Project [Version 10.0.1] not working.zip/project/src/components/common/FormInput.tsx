import React from 'react';

interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

const FormInput: React.FC<FormInputProps> = ({ label, ...props }) => {
  return (
    <div>
      <label className="block text-sm font-medium mb-2 dark:text-gray-200">
        {label}
      </label>
      <input
        {...props}
        className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600 
                   dark:text-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-transparent
                   transition-colors duration-200"
      />
    </div>
  );
};

export default FormInput;