import React from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useTheme } from '../hooks/useTheme';
import { Sun, Moon, ShoppingCart, User, Cpu, MessageCircle } from 'lucide-react';

interface NavbarProps {
  onChatOpen: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onChatOpen }) => {
  const { user, signOut } = useAuthStore();
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <nav className={`${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white'} shadow-lg`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="text-xl font-bold">PC Builder</Link>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            <Link to="/shop" className="hover:text-blue-500">Shop</Link>
            <Link to="/build" className="hover:text-blue-500">Build PC</Link>

            <button
              onClick={onChatOpen}
              className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700"
              title="Open Chat Assistant"
            >
              <MessageCircle size={20} />
            </button>

            {user ? (
              <>
                {user.role === 'customer' && (
                  <Link to="/cart" className="hover:text-blue-500">
                    <ShoppingCart size={20} />
                  </Link>
                )}
                <Link to="/profile" className="hover:text-blue-500">
                  <User size={20} />
                </Link>
                <button
                  onClick={signOut}
                  className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transform hover:translate-y-[-2px] transition-all"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-blue-500">Login</Link>
                <Link to="/register" className="hover:text-blue-500">Register</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};