import { useState } from 'react';
import { FilterState } from './types';

const initialFilters: FilterState = {
  category: null,
  brand: null,
  minPrice: null,
  maxPrice: null,
  sortBy: null,
};

export const useFilters = () => {
  const [filters, setFilters] = useState<FilterState>(initialFilters);

  const updateFilter = (key: keyof FilterState, value: string | number | null) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const resetFilters = () => {
    setFilters(initialFilters);
  };

  return {
    filters,
    updateFilter,
    resetFilters,
  };
};