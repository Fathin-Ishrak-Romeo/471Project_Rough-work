export interface FilterState {
  category: string | null;
  brand: string | null;
  minPrice: number | null;
  maxPrice: number | null;
  sortBy: 'price-asc' | 'price-desc' | null;
}

export type SortOption = {
  label: string;
  value: 'price-asc' | 'price-desc';
};