import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Product } from '../../types';
import ProductCard from './ProductCard';
import ProductFilters from './ProductFilters';
import { useFilters } from './useFilters';
import { FilterState } from './types';

const ProductList = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { filters, updateFilter, resetFilters } = useFilters();

  useEffect(() => {
    loadProducts(filters);
  }, [filters]);

  const loadProducts = async (filterState: FilterState) => {
    try {
      setLoading(true);
      let query = supabase
        .from('products')
        .select('*');

      // Apply category filter
      if (filterState.category && filterState.category !== '') {
        query = query.eq('category', filterState.category);
      }

      // Apply brand filter
      if (filterState.brand && filterState.brand !== '') {
        query = query.ilike('brand', `%${filterState.brand}%`);
      }

      // Apply price filters
      if (filterState.minPrice !== null) {
        query = query.gte('price', filterState.minPrice);
      }
      if (filterState.maxPrice !== null) {
        query = query.lte('price', filterState.maxPrice);
      }

      // Apply sorting
      if (filterState.sortBy) {
        query = query.order('price', { ascending: filterState.sortBy === 'price-asc' });
      }

      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching products:', error);
        return;
      }
      
      setProducts(data || []);
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <ProductFilters
        filters={filters}
        onUpdateFilter={updateFilter}
        onReset={resetFilters}
      />
      
      {loading ? (
        <div className="text-center py-8">Loading products...</div>
      ) : products.length === 0 ? (
        <div className="text-center py-8">No products found</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductList;