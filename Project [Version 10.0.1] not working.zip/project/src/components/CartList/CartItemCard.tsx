import React from 'react';
import { CartItem } from '../../types';
import { Minus, Plus, Trash2 } from 'lucide-react';

interface CartItemCardProps {
  item: CartItem;
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onRemove: (itemId: string) => void;
}

const CartItemCard = ({ item, onUpdateQuantity, onRemove }: CartItemCardProps) => {
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center gap-4">
      <img
        src={item.product.image_url}
        alt={item.product.name}
        className="w-24 h-24 object-cover rounded"
      />
      
      <div className="flex-1">
        <h3 className="font-semibold text-lg">{item.product.name}</h3>
        <p className="text-gray-600 dark:text-gray-400">{item.product.brand}</p>
        <p className="font-medium">${item.product.price.toFixed(2)}</p>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <Minus size={20} />
        </button>
        
        <span className="w-8 text-center">{item.quantity}</span>
        
        <button
          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          disabled={item.quantity >= item.product.stock}
        >
          <Plus size={20} />
        </button>

        <button
          onClick={() => onRemove(item.id)}
          className="p-1 text-red-500 hover:text-red-700 ml-4"
        >
          <Trash2 size={20} />
        </button>
      </div>
    </div>
  );
};

export default CartItemCard;