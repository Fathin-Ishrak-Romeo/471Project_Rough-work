import { supabase } from '../lib/supabase';
import { User } from '../types';

export const authService = {
  // ... existing methods ...

  async updateProfile(userId: string, data: { name?: string; email?: string; password?: string }) {
    const updates: any = {};
    
    if (data.name || data.email) {
      const { error } = await supabase
        .from('users')
        .update({ 
          name: data.name,
          email: data.email,
        })
        .eq('id', userId);
      
      if (error) throw error;
    }

    if (data.password) {
      const { error } = await supabase.auth.updateUser({
        password: data.password
      });
      
      if (error) throw error;
    }

    return true;
  },
};