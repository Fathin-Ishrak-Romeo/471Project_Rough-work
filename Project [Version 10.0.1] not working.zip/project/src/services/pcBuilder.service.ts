import { PCBuildRequest, PCBuildResult, PCComponent } from '../types/pcBuilder.types';
import { categories } from '../constants/categories';

// Mock database of PC components
const components: Record<string, PCComponent[]> = {
  processor: [
    { id: 'cpu1', name: 'AMD Ryzen 5 5600X', description: '6-core, 12-thread processor', price: 199, category: 'processor' },
    { id: 'cpu2', name: 'Intel Core i5-12600K', description: '10-core, 16-thread processor', price: 279, category: 'processor' },
    { id: 'cpu3', name: 'AMD Ryzen 7 5800X', description: '8-core, 16-thread processor', price: 349, category: 'processor' },
  ],
  graphics_card: [
    { id: 'gpu1', name: 'NVIDIA RTX 3060', description: '12GB GDDR6 graphics card', price: 329, category: 'graphics_card' },
    { id: 'gpu2', name: 'AMD RX 6600 XT', description: '8GB GDDR6 graphics card', price: 379, category: 'graphics_card' },
    { id: 'gpu3', name: 'NVIDIA RTX 3070', description: '8GB GDDR6X graphics card', price: 499, category: 'graphics_card' },
  ],
  // Add more component categories as needed
};

const generateBuild = (request: PCBuildRequest): PCBuildResult => {
  const { category, budget } = request;
  const selectedComponents: PCComponent[] = [];
  let remainingBudget = budget.max;

  // Component allocation percentages based on category
  const allocations = {
    gaming: {
      processor: 0.25,
      graphics_card: 0.4,
      // Add more components with their budget allocations
    },
    workstation: {
      processor: 0.35,
      graphics_card: 0.3,
      // Add more components with their budget allocations
    },
    // Add more category-specific allocations
  };

  // Select components based on budget allocation
  Object.entries(components).forEach(([componentType, options]) => {
    const allocation = allocations[category as keyof typeof allocations]?.[componentType as keyof typeof allocations['gaming']] || 0.2;
    const componentBudget = budget.max * allocation;
    
    const suitable = options.filter(c => c.price <= componentBudget)
      .sort((a, b) => b.price - a.price);
    
    if (suitable.length > 0) {
      const selected = suitable[0];
      selectedComponents.push(selected);
      remainingBudget -= selected.price;
    }
  });

  return {
    components: selectedComponents,
    totalPrice: selectedComponents.reduce((sum, comp) => sum + comp.price, 0),
    performance: {
      gaming: category === 'gaming' ? 85 : 60,
      productivity: category === 'workstation' ? 90 : 70,
      graphics: category === 'graphics' ? 88 : 65,
    },
  };
};

export const pcBuilderService = {
  generateBuild,
};