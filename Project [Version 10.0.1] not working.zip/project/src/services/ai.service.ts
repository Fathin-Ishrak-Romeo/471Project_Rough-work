import { pcBuilderService } from './pcBuilder.service';
import type { PCBuildRequest, PCBuildResult } from '../types/pcBuilder.types';
import type { Message } from '../components/Chat/types';

export const aiService = {
  async generatePCBuild(request: PCBuildRequest): Promise<PCBuildResult> {
    // Use the PC Builder service instead of Supabase function
    return pcBuilderService.generateBuild(request);
  },

  async getChatResponse(messages: Message[]): Promise<string> {
    // Mock AI chat response for now
    const lastMessage = messages[messages.length - 1];
    if (lastMessage.content.toLowerCase().includes('hello')) {
      return "Hi! I'm your PC building assistant. How can I help you today?";
    }
    return "I'm here to help you with PC building questions. What would you like to know?";
  }
};