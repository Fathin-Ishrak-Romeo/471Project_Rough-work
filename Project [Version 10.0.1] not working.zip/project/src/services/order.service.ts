import { supabase } from '../lib/supabase';
import { CartItem } from '../types';

export const orderService = {
  async createOrder(userId: string, items: CartItem[]) {
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert([
        {
          user_id: userId,
          status: 'completed',
          total_amount: items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0),
        },
      ])
      .select()
      .single();

    if (orderError) throw orderError;

    const orderItems = items.map(item => ({
      order_id: order.id,
      product_id: item.product_id,
      quantity: item.quantity,
      price: item.product.price,
    }));

    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(orderItems);

    if (itemsError) throw itemsError;

    // Clear cart after successful order
    await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', userId);

    return order;
  },

  async getOrderHistory(userId: string) {
    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        order_items:order_items(
          *,
          product:products(*)
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  },
};