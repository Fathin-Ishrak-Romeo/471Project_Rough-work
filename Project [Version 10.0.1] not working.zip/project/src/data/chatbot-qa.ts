// Predefined Q&A data for the chatbot
export interface ChatQuestion {
  id: string;
  question: string;
  answer: string;
  category: 'basics' | 'components' | 'performance' | 'cooling';
  followUpQuestions?: string[];
}

export const chatQuestions: ChatQuestion[] = [
  {
    id: 'basics-1',
    category: 'basics',
    question: 'What do I need to build a custom PC?',
    answer: `To build a custom PC, you'll need:
• CPU (Processor): The brain of your PC
• Motherboard: The main circuit board
• RAM (Memory): For temporary data storage
• Storage: SSD or HDD for data
• Graphics Card (GPU): For visual processing
• Power Supply Unit (PSU): Powers all components
• Case: Houses all components
• Cooling System: For temperature control
• Operating System: For running software`,
    followUpQuestions: ['cpu-gaming', 'gpu-choice', 'ram-choice']
  },
  {
    id: 'cpu-gaming',
    category: 'components',
    question: 'What CPU should I choose for gaming?',
    answer: `For gaming, here are the recommended options:
• High-end: Intel Core i7/i9 (13th Gen) or AMD Ryzen 7/9 (7000 series)
• Mid-range: Intel Core i5 or AMD Ryzen 5
• Budget: Intel Core i3 or AMD Ryzen 3

The choice depends on your budget and gaming needs.`,
    followUpQuestions: ['ram-choice', 'cooling-choice']
  },
  {
    id: 'ram-choice',
    category: 'components',
    question: 'What kind of RAM should I get for my build?',
    answer: `RAM recommendations based on usage:
• 8GB: Basic computing and light gaming
• 16GB: Recommended for gaming and content creation
• 32GB: Heavy multitasking and professional work
• 64GB+: Specialized workstations

Consider DDR4 vs DDR5 based on your motherboard compatibility.`,
    followUpQuestions: ['storage-difference', 'cooling-choice']
  },
  {
    id: 'storage-difference',
    category: 'components',
    question: 'What is the difference between SSD and HDD?',
    answer: `Storage types compared:
• SSD (Solid State Drive):
  - Faster speeds
  - More reliable
  - Energy efficient
  - Ideal for OS and programs
  - More expensive per GB

• HDD (Hard Disk Drive):
  - Slower speeds
  - More storage for the price
  - Good for mass storage
  - Better for archival`,
    followUpQuestions: ['case-size', 'psu-power']
  },
  {
    id: 'case-size',
    category: 'components',
    question: 'What size case should I get for my build?',
    answer: `Case sizes explained:
• Mini-ITX: Compact builds, limited space
• Mid-Tower: Most common, good airflow
• Full-Tower: High-end builds, multiple GPUs

Choose based on your components and space requirements.`,
    followUpQuestions: ['cooling-choice', 'airflow-tips']
  },
  {
    id: 'gpu-choice',
    category: 'components',
    question: 'Do I need a dedicated graphics card for my PC?',
    answer: `It depends on your needs:
• Gaming/3D Work: Yes, get a dedicated GPU
  - NVIDIA RTX series
  - AMD Radeon RX series

• Basic Use/Office Work: No
  - Integrated graphics sufficient
  - Intel/AMD built-in graphics okay`,
    followUpQuestions: ['gpu-budget', 'psu-power']
  },
  {
    id: 'psu-power',
    category: 'components',
    question: 'How much power do I need from my PSU?',
    answer: `PSU wattage guidelines:
• Basic Build: 300W-400W
• Mid-Range: 500W-650W
• High-End: 750W-1000W

Always add 100-150W for future upgrades.`,
    followUpQuestions: ['psu-efficiency', 'cooling-choice']
  },
  {
    id: 'overclocking',
    category: 'performance',
    question: 'What is overclocking, and should I do it?',
    answer: `Overclocking explained:
• Pros:
  - Increased performance
  - Better value from components

• Cons:
  - More heat generated
  - Requires better cooling
  - May void warranty
  - Needs stable power supply`,
    followUpQuestions: ['cooling-choice', 'psu-power']
  },
  {
    id: 'old-psu',
    category: 'components',
    question: 'Can I use an old power supply with my new build?',
    answer: `Consider these factors:
• Age: Replace if over 5 years old
• Wattage: Must meet new requirements
• Certification: 80 Plus recommended
• Connectors: Must match new components

When in doubt, buy new for safety.`,
    followUpQuestions: ['psu-power', 'psu-efficiency']
  },
  {
    id: 'cooling-choice',
    category: 'cooling',
    question: 'How can I ensure my PC stays cool during gaming?',
    answer: `Cooling tips:
• Use quality case fans
• Consider aftermarket CPU cooler
• Apply good thermal paste
• Maintain proper airflow
• Keep room temperature cool
• Clean dust regularly`,
    followUpQuestions: ['airflow-tips', 'liquid-vs-air']
  },
  {
    id: 'motherboard-gaming',
    category: 'components',
    question: 'What is the best motherboard for gaming?',
    answer: `Motherboard recommendations:
• Intel: Z690/Z790 for high-end
• AMD: X670/B550 for performance
• Budget: B660/B550

Consider: WiFi, USB ports, VRM cooling`,
    followUpQuestions: ['cpu-gaming', 'ram-choice']
  },
  {
    id: 'gpu-budget',
    category: 'components',
    question: 'What is a good budget GPU for gaming?',
    answer: `Budget GPU options:
• GTX 1660 Super: Great 1080p gaming
• RX 6600: Excellent price/performance
• RTX 3050: Entry-level ray tracing

All good for 1080p gaming at medium-high settings.`,
    followUpQuestions: ['psu-power', 'gpu-choice']
  },
  {
    id: 'liquid-vs-air',
    category: 'cooling',
    question: 'What are the benefits of liquid cooling vs. air cooling?',
    answer: `Cooling comparison:
• Air Cooling:
  - Cheaper
  - More reliable
  - Easier to maintain
  - Good for most builds

• Liquid Cooling:
  - Better cooling
  - Quieter operation
  - Looks better
  - More expensive`,
    followUpQuestions: ['cooling-choice', 'airflow-tips']
  }
];