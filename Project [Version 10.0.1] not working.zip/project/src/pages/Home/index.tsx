import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useTheme } from '../../hooks/useTheme';
import { ShoppingBag, Cpu, MessageCircle } from 'lucide-react';
import ChatBot from '../../components/Chat/ChatBot';

const Home = () => {
  const { user } = useAuthStore();
  const { isDarkMode } = useTheme();
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4 transform hover:scale-105 transition-transform">
          Welcome to PC Builder
        </h1>
        <p className="text-xl mb-8">Your one-stop shop for all PC components</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800 transform hover:scale-105 transition-all hover:shadow-xl">
            <h2 className="text-2xl font-semibold mb-4 dark:text-white">Shop Components</h2>
            <p className="mb-4 dark:text-gray-300">Browse our extensive collection of PC components.</p>
            <Link 
              to="/shop" 
              className="inline-flex items-center gap-2 bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transform hover:translate-y-[-2px] transition-all"
            >
              <ShoppingBag size={20} />
              Shop Now
            </Link>
          </div>
          
          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800 transform hover:scale-105 transition-all hover:shadow-xl">
            <h2 className="text-2xl font-semibold mb-4 dark:text-white">Build Your PC</h2>
            <p className="mb-4 dark:text-gray-300">Let AI help you build the perfect PC within your budget.</p>
            <Link 
              to="/build" 
              className="inline-flex items-center gap-2 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transform hover:translate-y-[-2px] transition-all"
            >
              <Cpu size={20} />
              Start Building
            </Link>
          </div>

          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800 transform hover:scale-105 transition-all hover:shadow-xl">
            <h2 className="text-2xl font-semibold mb-4 dark:text-white">Expert Chat</h2>
            <p className="mb-4 dark:text-gray-300">Get help from our AI-powered PC building assistant.</p>
            <button 
              onClick={() => setIsChatOpen(true)}
              className="inline-flex items-center gap-2 bg-purple-500 text-white px-6 py-2 rounded-lg hover:bg-purple-600 transform hover:translate-y-[-2px] transition-all"
            >
              <MessageCircle size={20} />
              Chat Now
            </button>
          </div>
        </div>
      </section>

      {!user && (
        <section className="text-center py-12 bg-gray-100 dark:bg-gray-800 mt-12 rounded-lg transform hover:scale-[1.02] transition-all">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Get Started Today</h2>
          <p className="mb-6 dark:text-gray-300">Create an account to start building your perfect PC</p>
          <Link 
            to="/register" 
            className="inline-block bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transform hover:translate-y-[-2px] transition-all"
          >
            Sign Up Now
          </Link>
        </section>
      )}

      <ChatBot isVisible={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </div>
  );
};

export default Home;