import React from 'react';
import ProductList from '../../components/ProductList';
import { useTheme } from '../../hooks/useTheme';

const BrandNewShop = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <h1 className="text-3xl font-bold mb-8">Brand New Components</h1>
      <ProductList shopType="brand_new" />
    </div>
  );
};

export default BrandNewShop;