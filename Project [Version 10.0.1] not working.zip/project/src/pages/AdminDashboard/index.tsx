import React from 'react';
import { useTheme } from '../../hooks/useTheme';
import ProductManagement from '../../components/ProductManagement';

const AdminDashboard = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>
      <ProductManagement />
    </div>
  );
};

export default AdminDashboard;