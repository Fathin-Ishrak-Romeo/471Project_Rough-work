import { createSupabaseClient } from '../config/supabase';

export const supabase = createSupabaseClient();