import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh } from 'three';

export const Computer = () => {
  const meshRef = useRef<Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime) * 0.3;
    }
  });

  return (
    <mesh ref={meshRef} scale={[2, 2, 2]}>
      <boxGeometry args={[1, 1.2, 0.8]} />
      <meshStandardMaterial
        color="#4f46e5"
        metalness={0.8}
        roughness={0.2}
      />
      {/* Monitor */}
      <mesh position={[0, 0.8, 0]}>
        <boxGeometry args={[1.2, 0.8, 0.1]} />
        <meshStandardMaterial color="#1a1a1a" />
      </mesh>
      {/* Screen */}
      <mesh position={[0, 0.8, 0.06]}>
        <boxGeometry args={[1.1, 0.7, 0.01]} />
        <meshStandardMaterial
          color="#00ff00"
          emissive="#00ff00"
          emissiveIntensity={0.2}
        />
      </mesh>
    </mesh>
  );
};