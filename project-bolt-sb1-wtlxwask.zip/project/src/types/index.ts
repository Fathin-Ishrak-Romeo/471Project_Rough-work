export interface User {
  id: string;
  email: string;
  role: 'admin' | 'customer' | 'specialist';
  name: string;
  avatar?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: {
    bdt: number;
    usd: number;
  };
  category: string;
  brand: string;
  condition: 'new' | 'used';
  images: string[];
  specs: Record<string, string>;
  stock: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}