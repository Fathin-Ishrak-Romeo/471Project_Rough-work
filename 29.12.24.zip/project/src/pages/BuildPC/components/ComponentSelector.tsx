import { useState } from 'react';
import { Product } from '../../../types';

interface ComponentSelectorProps {
  selectedComponents: Record<string, Product>;
  onComponentSelect: (category: string, product: Product) => void;
}

const COMPONENT_CATEGORIES = [
  'CPU',
  'Motherboard',
  'RAM',
  'Storage',
  'GPU',
  'Power Supply',
  'Case',
  'CPU Cooler'
];

const ComponentSelector = ({ selectedComponents, onComponentSelect }: ComponentSelectorProps) => {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all">
      <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Manual Selection</h2>
      
      <div className="space-y-4">
        {COMPONENT_CATEGORIES.map(category => (
          <div key={category} className="border-b dark:border-gray-700 pb-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{category}</h3>
              <button
                onClick={() => setActiveCategory(activeCategory === category ? null : category)}
                className="text-primary-500 hover:text-primary-600 transition-colors"
              >
                {selectedComponents[category] ? 'Change' : 'Select'}
              </button>
            </div>

            {selectedComponents[category] && (
              <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                <img
                  src={selectedComponents[category].image_url}
                  alt={selectedComponents[category].name}
                  className="w-16 h-16 object-cover rounded"
                />
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {selectedComponents[category].name}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    ৳{selectedComponents[category].price}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ComponentSelector;