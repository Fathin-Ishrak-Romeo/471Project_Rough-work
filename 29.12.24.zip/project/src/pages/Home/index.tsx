import { Link } from 'react-router-dom';
import { Monitor, Cpu, HardDrive } from 'lucide-react';

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary-600 to-primary-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-6">
              Build Your Dream PC
            </h1>
            <p className="text-xl mb-8">
              Customize your perfect computer with our expert guidance and quality components
            </p>
            <div className="flex justify-center gap-4">
              <Link
                to="/build-pc"
                className="bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Start Building
              </Link>
              <Link
                to="/shop"
                className="bg-transparent border-2 border-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-primary-600 transition-colors"
              >
                Browse Components
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="flex justify-center mb-4">
                <Monitor className="w-12 h-12 text-primary-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Expert Guidance</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Get personalized recommendations from our PC building experts
              </p>
            </div>
            <div className="text-center p-6">
              <div className="flex justify-center mb-4">
                <Cpu className="w-12 h-12 text-primary-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Quality Components</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Premium parts from trusted manufacturers with warranty
              </p>
            </div>
            <div className="text-center p-6">
              <div className="flex justify-center mb-4">
                <HardDrive className="w-12 h-12 text-primary-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Custom Builds</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Tailor your PC to your specific needs and budget
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-100 dark:bg-gray-800 py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Build Your PC?</h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            Let's create your perfect computer together
          </p>
          <Link
            to="/build-pc"
            className="bg-primary-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-primary-600 transition-colors"
          >
            Get Started
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;