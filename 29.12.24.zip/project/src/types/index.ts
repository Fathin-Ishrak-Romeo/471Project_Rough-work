export interface User {
  id: string;
  email: string;
  name: string;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  description: string;
  image_url: string;
  stock: number;
  created_at: string;
}

export interface CartItem {
  id: string;
  user_id: string;
  product_id: string;
  quantity: number;
  product: Product;
}

export interface Order {
  id: string;
  user_id: string;
  total_amount: number;
  payment_method: string;
  status: string;
  created_at: string;
  items: CartItem[];
}

export interface PCBuildSuggestion {
  id: string;
  budget_range: [number, number];
  usage_category: string;
  components: Product[];
  created_at: string;
}