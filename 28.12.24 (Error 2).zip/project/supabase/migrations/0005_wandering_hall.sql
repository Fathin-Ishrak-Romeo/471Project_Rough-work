/*
  # PC Builder Updates
  
  1. New Tables
    - `pc_usage_categories`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `description` (text)
      - `min_budget` (integer)
      - `max_budget` (integer)
      - `created_at` (timestamp)
      
  2. Security
    - Enable RLS on new tables
    - Add policies for public read access
*/

-- Create PC usage categories table
CREATE TABLE IF NOT EXISTS pc_usage_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text NOT NULL,
  min_budget integer NOT NULL,
  max_budget integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE pc_usage_categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "PC usage categories are viewable by everyone"
  ON pc_usage_categories
  FOR SELECT
  USING (true);

-- Insert default categories
INSERT INTO pc_usage_categories (name, description, min_budget, max_budget) VALUES
  ('Gaming PC', 'High-performance PC for gaming enthusiasts', 80000, 300000),
  ('Workstation', 'Professional workstation for heavy computational tasks', 100000, 500000),
  ('Graphic Design', 'Optimized for graphic design and creative work', 90000, 250000),
  ('Software Development', 'Ideal for programming and development work', 70000, 200000),
  ('Office Work', 'Perfect for business and office applications', 40000, 100000),
  ('Normal Day-to-day Use', 'Basic PC for everyday computing needs', 30000, 80000),
  ('Streaming', 'Configured for content streaming and light gaming', 60000, 150000),
  ('Content Creation', 'Balanced build for content creators', 100000, 300000)
ON CONFLICT (name) DO NOTHING;