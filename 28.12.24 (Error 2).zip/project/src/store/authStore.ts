import { create } from 'zustand';
import { User } from '../types';
import { supabase } from '../lib/supabase';

interface AuthState {
  user: User | null;
  loading: boolean;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signUp: async (email, password, name) => {
    // 1. Sign up the user
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { name },
      },
    });
    if (authError) throw authError;

    // 2. Create profile in profiles table
    if (authData.user) {
      const { error: profileError } = await supabase
        .from('profiles')
        .insert([
          {
            id: authData.user.id,
            email,
            name,
          },
        ]);
      if (profileError) {
        // Rollback auth if profile creation fails
        await supabase.auth.signOut();
        throw profileError;
      }
    }

    set({ user: authData.user as User });
  },
  signIn: async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;

    // Fetch profile data
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', data.user.id)
      .single();

    set({ user: { ...data.user, ...profile } as User });
  },
  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null });
  },
  updateProfile: async (data) => {
    const { error: authError } = await supabase.auth.updateUser({
      data,
    });
    if (authError) throw authError;

    // Update profile table
    const { error: profileError } = await supabase
      .from('profiles')
      .update(data)
      .eq('id', (await supabase.auth.getUser()).data.user?.id);

    if (profileError) throw profileError;

    set((state) => ({
      user: state.user ? { ...state.user, ...data } : null,
    }));
  },
}));