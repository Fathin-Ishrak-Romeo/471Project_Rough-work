import { useState } from 'react';
import { Product } from '../../../types';

interface ComponentSelectorProps {
  category: string;
  products: Product[];
  onSelect: (product: Product) => void;
  selectedProduct?: Product;
}

const ComponentSelector = ({ 
  category, 
  products, 
  onSelect, 
  selectedProduct 
}: ComponentSelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold">{category}</h3>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="text-primary-500 hover:text-primary-600"
        >
          {selectedProduct ? 'Change' : 'Select'}
        </button>
      </div>

      {selectedProduct && (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center gap-4">
          <img
            src={selectedProduct.image_url}
            alt={selectedProduct.name}
            className="w-16 h-16 object-cover rounded"
          />
          <div>
            <h4 className="font-medium">{selectedProduct.name}</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              ৳{selectedProduct.price}
            </p>
          </div>
        </div>
      )}

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">Select {category}</h3>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="border dark:border-gray-700 rounded-lg p-4 cursor-pointer hover:border-primary-500"
                  onClick={() => {
                    onSelect(product);
                    setIsOpen(false);
                  }}
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div>
                      <h4 className="font-medium">{product.name}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        ৳{product.price}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComponentSelector;