import { useState, useEffect } from 'react';
import { supabase } from '../../../lib/supabase';
import { motion } from 'framer-motion';

interface UsageCategory {
  id: string;
  name: string;
  description: string;
  min_budget: number;
  max_budget: number;
}

interface UsageSelectorProps {
  onSelect: (category: UsageCategory, budget: number) => void;
}

const UsageSelector = ({ onSelect }: UsageSelectorProps) => {
  const [categories, setCategories] = useState<UsageCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<UsageCategory | null>(null);
  const [budget, setBudget] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('pc_usage_categories')
        .select('*')
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategorySelect = (category: UsageCategory) => {
    setSelectedCategory(category);
    setBudget(category.min_budget);
  };

  const handleSubmit = () => {
    if (selectedCategory && budget >= selectedCategory.min_budget && budget <= selectedCategory.max_budget) {
      onSelect(selectedCategory, budget);
    }
  };

  if (loading) {
    return <div>Loading categories...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {categories.map((category) => (
          <motion.div
            key={category.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`cursor-pointer p-4 rounded-lg shadow-lg transition-all transform hover:shadow-xl
              ${selectedCategory?.id === category.id 
                ? 'bg-primary-500 text-white' 
                : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700'}`}
            onClick={() => handleCategorySelect(category)}
          >
            <h3 className="font-semibold mb-2">{category.name}</h3>
            <p className="text-sm opacity-90">{category.description}</p>
            <p className="text-sm mt-2">
              Budget: ৳{category.min_budget.toLocaleString()} - ৳{category.max_budget.toLocaleString()}
            </p>
          </motion.div>
        ))}
      </div>

      {selectedCategory && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Your Budget (৳)</label>
            <input
              type="number"
              value={budget}
              onChange={(e) => setBudget(Number(e.target.value))}
              min={selectedCategory.min_budget}
              max={selectedCategory.max_budget}
              className="w-full p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600"
            />
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSubmit}
            className="w-full bg-primary-500 text-white py-2 px-4 rounded-md hover:bg-primary-600 transition-colors"
          >
            Generate Build
          </motion.button>
        </div>
      )}
    </div>
  );
};

export default UsageSelector;