import { useState } from 'react';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';
import { supabase } from '../../lib/supabase';
import { Product } from '../../types';
import ComponentSelector from './components/ComponentSelector';
import PriceBreakdown from './components/PriceBreakdown';
import UsageSelector from './components/UsageSelector';
import { useAuthStore } from '../../store/authStore';

const COMPONENT_CATEGORIES = [
  'CPU',
  'Motherboard',
  'RAM',
  'Storage',
  'GPU',
  'Power Supply',
  'Case',
  'CPU Cooler'
];

interface UsageCategory {
  id: string;
  name: string;
  description: string;
  min_budget: number;
  max_budget: number;
}

const BuildPC = () => {
  const { user } = useAuthStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedComponents, setSelectedComponents] = useState<Record<string, Product>>({});
  const [loading, setLoading] = useState(false);
  const [showUsageSelector, setShowUsageSelector] = useState(true);

  const generateBuild = async (category: UsageCategory, budget: number) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('price', { ascending: false });

      if (error) throw error;

      const availableProducts = data || [];
      const suggestedBuild: Record<string, Product> = {};
      let remainingBudget = budget;

      // Allocate budget percentages based on usage category
      const budgetAllocations = getBudgetAllocations(category.name);

      // Select components based on budget allocation
      for (const [category, percentage] of Object.entries(budgetAllocations)) {
        const categoryBudget = budget * percentage;
        const component = availableProducts.find(p => 
          p.category === category && p.price <= categoryBudget
        );

        if (component) {
          suggestedBuild[category] = component;
          remainingBudget -= component.price;
        }
      }

      setSelectedComponents(suggestedBuild);
      setShowUsageSelector(false);
    } catch (error) {
      console.error('Error generating build:', error);
      toast.error('Failed to generate build');
    } finally {
      setLoading(false);
    }
  };

  const getBudgetAllocations = (usageCategory: string): Record<string, number> => {
    // Define budget allocation percentages based on usage category
    const allocations: Record<string, Record<string, number>> = {
      'Gaming PC': {
        'CPU': 0.25,
        'GPU': 0.35,
        'Motherboard': 0.15,
        'RAM': 0.10,
        'Storage': 0.05,
        'Power Supply': 0.05,
        'Case': 0.03,
        'CPU Cooler': 0.02
      },
      'Workstation': {
        'CPU': 0.35,
        'GPU': 0.25,
        'Motherboard': 0.15,
        'RAM': 0.12,
        'Storage': 0.05,
        'Power Supply': 0.04,
        'Case': 0.02,
        'CPU Cooler': 0.02
      },
      // Add more categories with their specific allocations
    };

    return allocations[usageCategory] || allocations['Gaming PC'];
  };

  const handleAddAllToCart = async () => {
    if (!user) {
      toast.error('Please sign in to add items to cart');
      return;
    }

    try {
      const cartItems = Object.values(selectedComponents).map(product => ({
        product_id: product.id,
        user_id: user.id,
        quantity: 1
      }));

      const { error } = await supabase
        .from('cart_items')
        .insert(cartItems);

      if (error) throw error;
      toast.success('All components added to cart');
    } catch (error) {
      console.error('Error adding to cart:', error);
      toast.error('Failed to add items to cart');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Build Your PC</h1>

      {showUsageSelector ? (
        <UsageSelector onSelect={generateBuild} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {COMPONENT_CATEGORIES.map(category => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <ComponentSelector
                  category={category}
                  products={products}
                  selectedProduct={selectedComponents[category]}
                  onSelect={(product) => setSelectedComponents(prev => ({
                    ...prev,
                    [category]: product
                  }))}
                />
              </motion.div>
            ))}
          </div>

          <div className="lg:col-span-1">
            <motion.div
              className="sticky top-8"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <PriceBreakdown selectedComponents={selectedComponents} />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleAddAllToCart}
                className="w-full mt-4 bg-primary-500 text-white py-3 px-4 rounded-lg hover:bg-primary-600 transition-colors"
              >
                Add All to Cart
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowUsageSelector(true)}
                className="w-full mt-2 bg-gray-500 text-white py-3 px-4 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Start Over
              </motion.button>
            </motion.div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BuildPC;