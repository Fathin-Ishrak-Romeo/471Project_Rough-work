import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { supabase } from '../../lib/supabase';
import { Product } from '../../types';
import ComponentSelector from './components/ComponentSelector';
import PriceBreakdown from './components/PriceBreakdown';

const COMPONENT_CATEGORIES = [
  'CPU',
  'Motherboard',
  'RAM',
  'Storage',
  'GPU',
  'Power Supply',
  'Case',
  'CPU Cooler'
];

const BuildPC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedComponents, setSelectedComponents] = useState<Record<string, Product>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('category');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const getProductsByCategory = (category: string) => {
    return products.filter(product => product.category === category);
  };

  const handleComponentSelect = (category: string, product: Product) => {
    setSelectedComponents(prev => ({
      ...prev,
      [category]: product
    }));
  };

  const handleSaveBuild = async () => {
    try {
      const { error } = await supabase
        .from('pc_build_suggestions')
        .insert([
          {
            components: selectedComponents,
            budget_min: 0, // Calculate based on components
            budget_max: 0, // Calculate based on components
            usage_category: 'Custom Build'
          }
        ]);

      if (error) throw error;
      toast.success('Build saved successfully');
    } catch (error) {
      console.error('Error saving build:', error);
      toast.error('Failed to save build');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Build Your PC</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {COMPONENT_CATEGORIES.map(category => (
            <ComponentSelector
              key={category}
              category={category}
              products={getProductsByCategory(category)}
              selectedProduct={selectedComponents[category]}
              onSelect={(product) => handleComponentSelect(category, product)}
            />
          ))}
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-8">
            <PriceBreakdown selectedComponents={selectedComponents} />
            <button
              onClick={handleSaveBuild}
              className="w-full mt-4 bg-primary-500 text-white py-3 px-4 rounded-lg hover:bg-primary-600 transition-colors"
            >
              Save Build
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuildPC;