import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { supabase } from '../../lib/supabase';
import { Product } from '../../types';
import { useAuthStore } from '../../store/authStore';
import SearchBar from './components/SearchBar';
import FilterPanel from './components/FilterPanel';
import ProductCard from './components/ProductCard';

const Shop = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('');
  const [selectedMinPrice, setSelectedMinPrice] = useState(0);
  const [selectedMaxPrice, setSelectedMaxPrice] = useState(0);
  const [sortOrder, setSortOrder] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in to add items to cart');
      navigate('/signin');
      return;
    }

    try {
      const { error } = await supabase
        .from('cart_items')
        .insert([
          {
            product_id: product.id,
            user_id: user.id,
            quantity: 1,
          },
        ]);

      if (error) throw error;
      toast.success('Added to cart');
    } catch (error: any) {
      if (error.code === '23505') {
        toast.error('Already in cart');
      } else {
        console.error('Error adding to cart:', error);
        toast.error('Failed to add to cart');
      }
    }
  };

  const getCategories = () => {
    return Array.from(new Set(products.map(p => p.category)));
  };

  const getBrands = () => {
    return Array.from(new Set(products.map(p => p.brand)));
  };

  const getMinPrice = () => {
    return Math.min(...products.map(p => p.price));
  };

  const getMaxPrice = () => {
    return Math.max(...products.map(p => p.price));
  };

  const filterProducts = () => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || product.category === selectedCategory;
      const matchesBrand = !selectedBrand || product.brand === selectedBrand;
      const matchesPrice = (!selectedMinPrice || product.price >= selectedMinPrice) &&
        (!selectedMaxPrice || product.price <= selectedMaxPrice);

      return matchesSearch && matchesCategory && matchesBrand && matchesPrice;
    });
  };

  const sortProducts = (filteredProducts: Product[]) => {
    switch (sortOrder) {
      case 'price_asc':
        return [...filteredProducts].sort((a, b) => a.price - b.price);
      case 'price_desc':
        return [...filteredProducts].sort((a, b) => b.price - a.price);
      case 'name_asc':
        return [...filteredProducts].sort((a, b) => a.name.localeCompare(b.name));
      case 'name_desc':
        return [...filteredProducts].sort((a, b) => b.name.localeCompare(a.name));
      default:
        return filteredProducts;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  const filteredProducts = sortProducts(filterProducts());

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Shop Components</h1>

      <div className="mb-8">
        <SearchBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <FilterPanel
            categories={getCategories()}
            brands={getBrands()}
            minPrice={getMinPrice()}
            maxPrice={getMaxPrice()}
            selectedCategory={selectedCategory}
            selectedBrand={selectedBrand}
            selectedMinPrice={selectedMinPrice}
            selectedMaxPrice={selectedMaxPrice}
            sortOrder={sortOrder}
            onCategoryChange={setSelectedCategory}
            onBrandChange={setSelectedBrand}
            onMinPriceChange={setSelectedMinPrice}
            onMaxPriceChange={setSelectedMaxPrice}
            onSortOrderChange={setSortOrder}
            onReset={() => {
              setSelectedCategory('');
              setSelectedBrand('');
              setSelectedMinPrice(0);
              setSelectedMaxPrice(0);
              setSortOrder('');
              setSearchQuery('');
            }}
          />
        </div>

        <div className="lg:col-span-3">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">No products found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Shop;