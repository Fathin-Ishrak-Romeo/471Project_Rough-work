import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { supabase } from '../../../lib/supabase';
import { Product } from '../../../types';

export const useSaveBuild = (userId: string | undefined) => {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);

  const saveBuild = async (components: Record<string, Product>) => {
    if (!userId) {
      toast.error('Please sign in to save your build');
      navigate('/signin');
      return;
    }

    if (Object.keys(components).length === 0) {
      toast.error('Please select at least one component');
      return;
    }

    setSaving(true);
    try {
      const totalPrice = Object.values(components).reduce(
        (sum, component) => sum + component.price, 
        0
      );

      const { error } = await supabase.from('saved_builds').insert([{
        user_id: userId,
        name: `Custom Build ${new Date().toLocaleDateString()}`,
        components,
        usage_category: 'Custom',
        total_price: totalPrice
      }]);

      if (error) throw error;
      toast.success('Build saved successfully');
      navigate('/all-builds');
    } catch (error) {
      console.error('Error saving build:', error);
      toast.error('Failed to save build');
    } finally {
      setSaving(false);
    }
  };

  return { saveBuild, saving };
};