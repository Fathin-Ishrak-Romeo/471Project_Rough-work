import { useState } from 'react';
import { Product } from '../../../types';
import { toast } from 'react-hot-toast';
import { supabase } from '../../../lib/supabase';

export const useComponentSelection = (userId: string | undefined) => {
  const [selectedComponents, setSelectedComponents] = useState<Record<string, Product>>({});
  const [showComponentModal, setShowComponentModal] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const handleComponentSelect = (category: string, product: Product) => {
    setSelectedComponents(prev => ({
      ...prev,
      [category]: product
    }));
    setShowComponentModal(false);
  };

  const calculateTotal = () => {
    return Object.values(selectedComponents).reduce(
      (total, product) => total + product.price,
      0
    );
  };

  const saveBuild = async () => {
    if (!userId) {
      toast.error('Please sign in to save your build');
      return;
    }

    if (Object.keys(selectedComponents).length === 0) {
      toast.error('Please select at least one component');
      return;
    }

    try {
      const { error } = await supabase.from('saved_builds').insert([{
        user_id: userId,
        name: 'Custom Build',
        components: selectedComponents,
        usage_category: 'Custom',
        total_price: calculateTotal()
      }]);

      if (error) throw error;
      toast.success('Build saved successfully');
    } catch (error) {
      console.error('Error saving build:', error);
      toast.error('Failed to save build');
    }
  };

  return {
    selectedComponents,
    showComponentModal,
    activeCategory,
    setShowComponentModal,
    setActiveCategory,
    handleComponentSelect,
    calculateTotal,
    saveBuild
  };
};