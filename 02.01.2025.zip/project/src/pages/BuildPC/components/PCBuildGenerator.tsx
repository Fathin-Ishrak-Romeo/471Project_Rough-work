import { useState } from 'react';
import { toast } from 'react-hot-toast';
import { Product } from '../../../types';
import { generateBuildSuggestion } from '../utils/buildGenerator';

interface PCBuildGeneratorProps {
  onAddToCart: (products: Product[]) => void;
}

const PC_USAGE_CATEGORIES = [
  'Gaming PC',
  'Workstation',
  'Graphic Design',
  'Software Development',
  'Office Work',
  'Normal Day-to-day Use',
  'Streaming',
  'Content Creation'
];

const PCBuildGenerator = ({ onAddToCart }: PCBuildGeneratorProps) => {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [minBudget, setMinBudget] = useState('');
  const [maxBudget, setMaxBudget] = useState('');
  const [suggestedComponents, setSuggestedComponents] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerateBuild = async () => {
    if (!selectedCategory || !minBudget || !maxBudget) {
      toast.error('Please fill in all fields');
      return;
    }

    const min = parseInt(minBudget);
    const max = parseInt(maxBudget);

    if (min > max) {
      toast.error('Minimum budget cannot be greater than maximum budget');
      return;
    }

    setLoading(true);
    try {
      const components = await generateBuildSuggestion(selectedCategory, min, max);
      if (components.length === 0) {
        toast.error('Sorry! Requirements cannot be fulfilled within this budget.');
        return;
      }
      setSuggestedComponents(components);
      toast.success('Build generated successfully');
    } catch (error) {
      console.error('Error generating build:', error);
      toast.error('Failed to generate build');
    } finally {
      setLoading(false);
    }
  };

  const handleBuildAgain = () => {
    handleGenerateBuild();
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 dark:text-white">PC Build Generator</h2>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2 dark:text-gray-200">
            PC Usage Category
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          >
            <option value="">Select Category</option>
            {PC_USAGE_CATEGORIES.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2 dark:text-gray-200">
              Minimum Budget (৳)
            </label>
            <input
              type="number"
              value={minBudget}
              onChange={(e) => setMinBudget(e.target.value)}
              className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="Min Budget"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2 dark:text-gray-200">
              Maximum Budget (৳)
            </label>
            <input
              type="number"
              value={maxBudget}
              onChange={(e) => setMaxBudget(e.target.value)}
              className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
              placeholder="Max Budget"
            />
          </div>
        </div>

        <button
          onClick={handleGenerateBuild}
          disabled={loading}
          className="w-full bg-primary-500 text-white py-3 rounded-lg hover:bg-primary-600 transition-colors"
        >
          {loading ? 'Generating...' : 'Generate Build'}
        </button>

        {suggestedComponents.length > 0 && (
          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-4 dark:text-white">
              Suggested Components
            </h3>
            <div className="space-y-4">
              {suggestedComponents.map(component => (
                <div
                  key={component.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={component.image_url}
                      alt={component.name}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div>
                      <p className="font-medium dark:text-white">{component.name}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-300">৳{component.price}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4 mt-6">
              <button
                onClick={handleBuildAgain}
                className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white py-3 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
              >
                Build Again
              </button>
              <button
                onClick={() => onAddToCart(suggestedComponents)}
                className="flex-1 bg-primary-500 text-white py-3 rounded-lg hover:bg-primary-600 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PCBuildGenerator;