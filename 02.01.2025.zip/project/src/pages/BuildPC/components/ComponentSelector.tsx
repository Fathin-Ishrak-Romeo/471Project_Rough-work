import { useState } from 'react';
import { Product } from '../../../types';
import ComponentModal from './ComponentModal';
import PriceBreakdown from './PriceBreakdown';

interface ComponentSelectorProps {
  selectedComponents: Record<string, Product>;
  onComponentSelect: (category: string, product: Product) => void;
  onSaveBuild: () => void;
  onAddToCart: () => void;
}

const COMPONENT_CATEGORIES = [
  'CPU',
  'Motherboard',
  'RAM',
  'Storage',
  'GPU',
  'Power Supply',
  'Case',
  'CPU Cooler'
];

const ComponentSelector = ({
  selectedComponents,
  onComponentSelect,
  onSaveBuild,
  onAddToCart
}: ComponentSelectorProps) => {
  const [showModal, setShowModal] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const handleSelectClick = (category: string) => {
    setActiveCategory(category);
    setShowModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-6">Manual Selection</h2>
        
        <div className="space-y-4">
          {COMPONENT_CATEGORIES.map(category => (
            <div key={category} className="border-b dark:border-gray-700 pb-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-medium">{category}</h3>
                <button
                  onClick={() => handleSelectClick(category)}
                  className="text-primary-500 hover:text-primary-600 transition-colors"
                >
                  {selectedComponents[category] ? 'Change' : 'Select'}
                </button>
              </div>

              {selectedComponents[category] && (
                <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                  <img
                    src={selectedComponents[category].image_url}
                    alt={selectedComponents[category].name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div>
                    <p className="font-medium">
                      {selectedComponents[category].name}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      ৳{selectedComponents[category].price}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-6 space-y-4">
          <PriceBreakdown selectedComponents={selectedComponents} />
          
          <div className="flex gap-4">
            <button
              onClick={onSaveBuild}
              className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white py-3 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
            >
              Save Build
            </button>
            <button
              onClick={onAddToCart}
              className="flex-1 bg-primary-500 text-white py-3 rounded-lg hover:bg-primary-600 transition-colors"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>

      {showModal && activeCategory && (
        <ComponentModal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          category={activeCategory}
          onSelect={(product) => onComponentSelect(activeCategory, product)}
        />
      )}
    </div>
  );
};

export default ComponentSelector;