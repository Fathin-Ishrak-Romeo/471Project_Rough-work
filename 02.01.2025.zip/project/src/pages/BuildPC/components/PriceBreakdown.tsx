import { Product } from '../../../types';

interface PriceBreakdownProps {
  selectedComponents: Record<string, Product>;
}

const PriceBreakdown = ({ selectedComponents }: PriceBreakdownProps) => {
  const calculateTotal = () => {
    return Object.values(selectedComponents).reduce(
      (total, product) => total + product.price,
      0
    );
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-semibold mb-4">Price Breakdown</h3>
      <div className="space-y-2">
        {Object.entries(selectedComponents).map(([category, product]) => (
          <div key={category} className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">{category}</span>
            <span>৳{product.price}</span>
          </div>
        ))}
        <div className="pt-2 border-t dark:border-gray-700">
          <div className="flex justify-between font-semibold">
            <span>Total</span>
            <span>৳{calculateTotal()}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PriceBreakdown;