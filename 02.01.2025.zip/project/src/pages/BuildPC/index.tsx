import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { useAuthStore } from '../../store/authStore';
import { Product } from '../../types';
import { cartService } from '../../services/cartService';
import ComponentSelector from './components/ComponentSelector';
import PCBuildGenerator from './components/PCBuildGenerator';
import { useComponentSelection } from './hooks/useComponentSelection';

const BuildPC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const {
    selectedComponents,
    handleComponentSelect,
    calculateTotal,
    saveBuild
  } = useComponentSelection(user?.id);

  const handleAddToCart = async () => {
    if (!user) {
      toast.error('Please sign in to add items to cart');
      navigate('/signin');
      return;
    }

    if (Object.keys(selectedComponents).length === 0) {
      toast.error('Please select at least one component');
      return;
    }

    try {
      for (const component of Object.values(selectedComponents)) {
        await cartService.addToCart(user.id, component);
      }
      toast.success('Added all components to cart');
    } catch (error) {
      console.error('Error adding to cart:', error);
      toast.error('Failed to add items to cart');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Build Your PC</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <PCBuildGenerator onAddToCart={handleAddToCart} />
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-8">
            <ComponentSelector
              selectedComponents={selectedComponents}
              onComponentSelect={handleComponentSelect}
              onSaveBuild={saveBuild}
              onAddToCart={handleAddToCart}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuildPC;