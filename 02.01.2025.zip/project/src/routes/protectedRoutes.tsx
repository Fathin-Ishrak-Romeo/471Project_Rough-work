import { Route } from 'react-router-dom';
import Cart from '../pages/Cart';
import Profile from '../pages/Profile';
import OrderHistory from '../pages/OrderHistory';
import BuildPC from '../pages/BuildPC';
import AllBuilds from '../pages/AllBuilds';

export const protectedRoutes = (
  <>
    <Route path="/cart" element={<Cart />} />
    <Route path="/profile" element={<Profile />} />
    <Route path="/order-history" element={<OrderHistory />} />
    <Route path="/build-pc" element={<BuildPC />} />
    <Route path="/all-builds" element={<AllBuilds />} />
  </>
);