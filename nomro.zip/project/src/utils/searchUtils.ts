// Check if search query matches continuously from the end of product name
export const matchesFromEnd = (productName: string, searchQuery: string): boolean => {
  // Remove any extra spaces and convert to lowercase for case-insensitive comparison
  const cleanProductName = productName.trim().toLowerCase();
  const cleanQuery = searchQuery.trim().toLowerCase();

  // If search query is empty, return true (show all products)
  if (!cleanQuery) {
    return true;
  }

  // If search query is longer than product name, no match possible
  if (cleanQuery.length > cleanProductName.length) {
    return false;
  }

  // Get the end portion of the product name
  const productEnd = cleanProductName.slice(-cleanQuery.length);
  
  // Check if the query matches exactly with the end portion
  return productEnd === cleanQuery;
};