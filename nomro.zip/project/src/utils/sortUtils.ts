// Sorting functions for products
export const sortProducts = (a: number, b: number, order: 'asc' | 'desc') => {
  return order === 'asc' ? a - b : b - a;
};