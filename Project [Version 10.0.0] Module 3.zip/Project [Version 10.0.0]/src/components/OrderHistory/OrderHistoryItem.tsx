import React from 'react';
import { formatDate } from '../../utils/date';
import { formatCurrency } from '../../utils/currency';
import type { Order } from '../../types';

interface OrderHistoryItemProps {
  order: Order;
}

const OrderHistoryItem: React.FC<OrderHistoryItemProps> = ({ order }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden animate-slide-up">
      <div className="p-4 border-b dark:border-gray-700">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-semibold dark:text-gray-200">
              Order #{order.id.slice(0, 8)}
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {formatDate(order.created_at)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold dark:text-gray-200">
              {formatCurrency(order.total_amount)}
            </p>
            <span className="inline-block px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
              {order.status}
            </span>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="space-y-4">
          {order.order_items.map((item) => (
            <div key={item.id} className="flex items-center space-x-4">
              <img
                src={item.product.image_url}
                alt={item.product.name}
                className="w-16 h-16 object-cover rounded"
              />
              <div className="flex-1">
                <h4 className="font-medium dark:text-gray-200">{item.product.name}</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Quantity: {item.quantity} × {formatCurrency(item.price)}
                </p>
              </div>
              <div className="text-right">
                <p className="font-medium dark:text-gray-200">
                  {formatCurrency(item.quantity * item.price)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OrderHistoryItem;