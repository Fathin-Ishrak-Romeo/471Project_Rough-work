export interface PCBuildRequest {
  category: string;
  budget: {
    min: number;
    max: number;
  };
  preferences: string[];
}

export interface PCComponent {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
}

export interface PCBuildResult {
  components: PCComponent[];
  totalPrice: number;
  performance: {
    gaming?: number;
    productivity?: number;
    graphics?: number;
  };
}