import React from 'react';
import type { PCBuildResult } from './types';
import { formatCurrency } from '../../utils/currency';

interface PCBuildResultProps {
  result: PCBuildResult;
  onReset: () => void;
}

const PCBuildResult: React.FC<PCBuildResultProps> = ({ result, onReset }) => {
  const totalCost = result.components.reduce((sum, comp) => sum + comp.price, 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Recommended Build</h3>
        <button
          onClick={onReset}
          className="text-blue-500 hover:text-blue-600"
        >
          Start New Build
        </button>
      </div>

      <div className="space-y-4">
        {result.components.map((component) => (
          <div
            key={component.id}
            className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
          >
            <div>
              <h4 className="font-medium">{component.name}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {component.description}
              </p>
            </div>
            <span className="font-medium">{formatCurrency(component.price)}</span>
          </div>
        ))}
      </div>

      <div className="border-t pt-4">
        <div className="flex justify-between items-center">
          <span className="text-lg font-semibold">Total Cost:</span>
          <span className="text-lg font-semibold">{formatCurrency(totalCost)}</span>
        </div>
      </div>

      <button
        onClick={() => {/* TODO: Add to cart functionality */}}
        className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600"
      >
        Add All to Cart
      </button>
    </div>
  );
};

export default PCBuildResult;