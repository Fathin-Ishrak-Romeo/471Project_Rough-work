export const categories = [
  { value: 'gaming', label: 'Gaming PC' },
  { value: 'workstation', label: 'Workstation' },
  { value: 'graphics', label: 'Graphics Design' },
  { value: 'development', label: 'Software Development' },
  { value: 'office', label: 'Office/Web Browsing' },
  { value: 'streaming', label: 'Streaming/Content Creation' },
] as const;