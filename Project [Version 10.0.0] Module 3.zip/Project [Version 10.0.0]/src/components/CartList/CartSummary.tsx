import React, { useState } from 'react';
import { CartItem } from '../../types';
import { CreditCard, Wallet } from 'lucide-react';

interface CartSummaryProps {
  items: CartItem[];
}

const CartSummary = ({ items }: CartSummaryProps) => {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'bank' | 'ewallet'>('card');
  
  const subtotal = items.reduce((sum, item) => 
    sum + (item.product.price * item.quantity), 0
  );
  
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + tax;

  const handleCheckout = async () => {
    // TODO: Implement payment processing
    alert('Payment processing will be implemented here');
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow sticky top-4">
      <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
      
      <div className="space-y-2 mb-4">
        <div className="flex justify-between">
          <span>Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span>Tax (10%)</span>
          <span>${tax.toFixed(2)}</span>
        </div>
        <div className="flex justify-between font-semibold text-lg border-t pt-2">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="font-medium mb-2">Payment Method</h3>
        <div className="space-y-2">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="payment"
              value="card"
              checked={paymentMethod === 'card'}
              onChange={(e) => setPaymentMethod('card')}
            />
            <CreditCard size={20} />
            <span>Credit/Debit Card</span>
          </label>
          
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="payment"
              value="bank"
              checked={paymentMethod === 'bank'}
              onChange={(e) => setPaymentMethod('bank')}
            />
            <Wallet size={20} />
            <span>Bank Transfer</span>
          </label>
          
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="payment"
              value="ewallet"
              checked={paymentMethod === 'ewallet'}
              onChange={(e) => setPaymentMethod('ewallet')}
            />
            <Wallet size={20} />
            <span>E-Wallet</span>
          </label>
        </div>
      </div>

      <button
        onClick={handleCheckout}
        className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
      >
        Proceed to Checkout
      </button>
    </div>
  );
};

export default CartSummary;