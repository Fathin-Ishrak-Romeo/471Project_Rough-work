export const categories = [
  { value: 'processor', label: 'Processors' },
  { value: 'graphics_card', label: 'Graphics Cards' },
  { value: 'motherboard', label: 'Motherboards' },
  { value: 'ram', label: 'RAM' },
  { value: 'storage', label: 'Storage' },
  { value: 'power_supply', label: 'Power Supplies' },
  { value: 'case', label: 'Cases' },
] as const;

export type CategoryValue = typeof categories[number]['value'];