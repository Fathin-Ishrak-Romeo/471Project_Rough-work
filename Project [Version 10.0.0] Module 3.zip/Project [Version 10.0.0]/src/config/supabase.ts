import { createClient } from '@supabase/supabase-js';

// Supabase configuration
export const SUPABASE_CONFIG = {
  url: import.meta.env.VITE_SUPABASE_URL,
  anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY,
} as const;

// Validate configuration
export const validateSupabaseConfig = () => {
  if (!SUPABASE_CONFIG.url || !SUPABASE_CONFIG.anonKey) {
    throw new Error(
      'Missing Supabase configuration. Please check your .env file and ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set.'
    );
  }

  try {
    // Validate URL format
    new URL(SUPABASE_CONFIG.url);
  } catch (error) {
    throw new Error(
      'Invalid Supabase URL format. Please check your VITE_SUPABASE_URL in .env file.'
    );
  }
};

// Create and export Supabase client
export const createSupabaseClient = () => {
  validateSupabaseConfig();
  return createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
};