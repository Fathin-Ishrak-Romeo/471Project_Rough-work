import { supabase } from '../lib/supabase';
import { Product } from '../types';
import { FilterState } from '../components/ProductList/types';

export const productService = {
  async getProducts(shopType: string, filters: FilterState) {
    let query = supabase
      .from('products')
      .select('*')
      .eq('shop_type', shopType);

    if (filters.category) {
      query = query.eq('category', filters.category);
    }
    if (filters.brand) {
      query = query.eq('brand', filters.brand);
    }
    if (filters.minPrice) {
      query = query.gte('price', filters.minPrice);
    }
    if (filters.maxPrice) {
      query = query.lte('price', filters.maxPrice);
    }
    if (filters.condition) {
      query = query.eq('condition', filters.condition);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  async addProduct(product: Omit<Product, 'id'>) {
    const { data, error } = await supabase
      .from('products')
      .insert([product]);
    if (error) throw error;
    return data;
  },

  async updateProduct(id: string, updates: Partial<Product>) {
    const { data, error } = await supabase
      .from('products')
      .update(updates)
      .eq('id', id);
    if (error) throw error;
    return data;
  },

  async deleteProduct(id: string) {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);
    if (error) throw error;
    return true;
  },
};