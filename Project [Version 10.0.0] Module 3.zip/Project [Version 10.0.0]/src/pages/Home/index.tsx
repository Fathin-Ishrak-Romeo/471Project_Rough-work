import React from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useTheme } from '../../hooks/useTheme';
import { ShoppingBag, Cpu, MessageCircle } from 'lucide-react';

const Home = () => {
  const { user } = useAuthStore();
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4">Welcome to PC Builder</h1>
        <p className="text-xl mb-8">Your one-stop shop for all PC components</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800">
            <h2 className="text-2xl font-semibold mb-4">Shop Components</h2>
            <p className="mb-4">Browse our extensive collection of PC components.</p>
            <Link to="/shop" className="inline-flex items-center gap-2 bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600">
              <ShoppingBag size={20} />
              Shop Now
            </Link>
          </div>
          
          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800">
            <h2 className="text-2xl font-semibold mb-4">Build Your PC</h2>
            <p className="mb-4">Let AI help you build the perfect PC within your budget.</p>
            <Link to="/build" className="inline-flex items-center gap-2 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600">
              <Cpu size={20} />
              Start Building
            </Link>
          </div>

          <div className="p-6 rounded-lg shadow-lg bg-white dark:bg-gray-800">
            <h2 className="text-2xl font-semibold mb-4">Expert Chat</h2>
            <p className="mb-4">Get help from our AI-powered PC building assistant.</p>
            <button 
              onClick={() => {/* TODO: Open chat */}} 
              className="inline-flex items-center gap-2 bg-purple-500 text-white px-6 py-2 rounded-lg hover:bg-purple-600"
            >
              <MessageCircle size={20} />
              Chat Now
            </button>
          </div>
        </div>
      </section>

      {!user && (
        <section className="text-center py-12 bg-gray-100 dark:bg-gray-800 mt-12 rounded-lg">
          <h2 className="text-2xl font-bold mb-4">Get Started Today</h2>
          <p className="mb-6">Create an account to start building your perfect PC</p>
          <Link to="/register" className="inline-block bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600">
            Sign Up Now
          </Link>
        </section>
      )}
    </div>
  );
};

export default Home;