import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useRegisterForm } from './useRegisterForm';
import FormInput from '../../components/common/FormInput';
import FormButton from '../../components/common/FormButton';

const RegisterForm: React.FC = () => {
  const { formData, error, handleChange, handleSubmit } = useRegisterForm();

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <FormInput
        label="Name"
        type="text"
        value={formData.name}
        onChange={(e) => handleChange('name', e.target.value)}
        required
      />

      <FormInput
        label="Email"
        type="email"
        value={formData.email}
        onChange={(e) => handleChange('email', e.target.value)}
        required
      />

      <FormInput
        label="Password"
        type="password"
        value={formData.password}
        onChange={(e) => handleChange('password', e.target.value)}
        required
      />

      <FormInput
        label="Confirm Password"
        type="password"
        value={formData.confirmPassword}
        onChange={(e) => handleChange('confirmPassword', e.target.value)}
        required
      />

      <FormButton type="submit">Register</FormButton>
    </form>
  );
};

export default RegisterForm;