import React from 'react';
import RegisterForm from './RegisterForm';
import { Link } from 'react-router-dom';

const Register: React.FC = () => {
  return (
    <div className="max-w-md mx-auto">
      <h1 className="text-3xl font-bold text-center mb-8 dark:text-white">Register</h1>
      
      <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
        <RegisterForm />

        <p className="text-center mt-6 dark:text-gray-300">
          Already have an account?{' '}
          <Link 
            to="/login" 
            className="text-primary-500 hover:text-primary-600 transition-colors duration-200"
          >
            Login here
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Register;