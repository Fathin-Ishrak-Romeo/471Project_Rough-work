import React from 'react';
import ProductList from '../../components/ProductList';
import { useTheme } from '../../hooks/useTheme';

const Shop = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className={`${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <h1 className="text-3xl font-bold mb-8">PC Components Shop</h1>
      <ProductList />
    </div>
  );
};

export default Shop;